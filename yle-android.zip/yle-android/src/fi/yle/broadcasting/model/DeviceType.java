package fi.yle.broadcasting.model;

public enum DeviceType {
    YleDeviceMobilePhone(0),
    YleDevicePortableVideo(1),
    YleDeviceNormalVehicle(2),
    YleDeviceHeavyDutyVehicle(3);
    
    private final int value;

    private DeviceType(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }
    
    public static DeviceType valueOf(int value) {
        for (DeviceType dt : DeviceType.values()) {
            if (dt.value == value) {
                return dt;
            }
        }
        return null;
    }
}
