package fi.yle.broadcasting.model;

public enum SignalType {
    YleMeasurementSignalNone(1),
    YleMeasurementSignalAverage(2),
    YleMeasurementSignalGood(3);
    
    private final int value;

    private SignalType(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }
    
    public static SignalType valueOf(int value) {
        for (SignalType st : SignalType.values()) {
            if (st.value == value) {
                return st;
            }
        }
        return null;
    }
}
