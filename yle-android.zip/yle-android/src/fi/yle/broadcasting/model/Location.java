package fi.yle.broadcasting.model;

import android.text.TextUtils;

public class Location {

    private Integer storageId;
    private String cloudId;
    
    private final String name;
    private final LocationDetails details;
    
    public Location(Integer storageId, String cloudId, String name, LocationDetails details) {
        if (name == null) {
            throw new IllegalArgumentException("name can not be null");
        }
        
        this.storageId = storageId;
        this.cloudId = cloudId;
        this.name = name;
        this.details = details;
    }
    
    public Integer getStorageId() {
        return this.storageId;
    }
    
    public void setStorageId(int storageId) {
        if (this.storageId != null) {
            throw new IllegalStateException("storageId already set");
        }
        
        this.storageId = storageId;
    }
    
    public String getCloudId() {
        return this.cloudId;
    }
    
    public void setCloudId(String cloudId) {
        if (this.cloudId != null) {
            throw new IllegalStateException("cloudId already set");
        }
        
        this.cloudId = cloudId;
    }

    public String getName() {
        return this.name;
    }
    
    public LocationDetails getDetails() {
        return this.details;
    }
    
    @Override
    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        
        if (o instanceof Location == false) {
            return false;
        }
        
        Location rhs = (Location)o;
        
        return  ((this.storageId != null && this.storageId.equals(rhs.storageId)) || (this.storageId == rhs.storageId))
                && TextUtils.equals(this.cloudId, rhs.cloudId)
                && TextUtils.equals(this.name, rhs.name)
                && ((this.details != null && this.details.equals(rhs.details)) || (this.details == rhs.details));
    }

}
