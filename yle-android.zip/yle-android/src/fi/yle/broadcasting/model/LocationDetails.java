package fi.yle.broadcasting.model;

import android.text.TextUtils;

public class LocationDetails {
    private final double longitude;
    private final double latitude;
    private final DeviceType deviceType;
    private final NetworkType networkType;
    private final BroadcastType broadcastType;
    private final SignalType signalType;
    private final String details;
    private final String electricitySources;
    private final String imageUri;
    
    public LocationDetails(
            double longitude, 
            double latitude, 
            DeviceType deviceType,
            NetworkType networkType, 
            BroadcastType broadcastType, 
            SignalType signalType,
            String details, 
            String electricitySources,
            String imageUri) {
        
        if (details == null) {
            throw new IllegalArgumentException("details can not be null");
        }
        
        if (electricitySources == null) {
            throw new IllegalArgumentException("electricitySources can not be null");
        }
        
        this.longitude = longitude;
        this.latitude = latitude;
        this.deviceType = deviceType;
        this.networkType = networkType;
        this.broadcastType = broadcastType;
        this.signalType = signalType;
        this.details = details;
        this.electricitySources = electricitySources;
        this.imageUri = imageUri;
    }
    
    public Double getLongitude() {
        return this.longitude;
    }
    public Double getLatitude() {
        return this.latitude;
    }
    public DeviceType getDeviceType() {
        return this.deviceType;
    }
    public NetworkType getNetworkType() {
        return this.networkType;
    }
    public BroadcastType getBroadcastType() {
        return this.broadcastType;
    }
    public SignalType getSignalType() {
        return this.signalType;
    }
    public String getDetails() {
        return this.details;
    }
    public String getElectricitySources() {
        return this.electricitySources;
    }
    public String getImageUri() {
        return this.imageUri;
    }
        
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        
        if (o instanceof LocationDetails == false) {
            return false;
        }
        
        LocationDetails rhs = (LocationDetails)o;
        
        return this.latitude == rhs.latitude
                && this.longitude == rhs.longitude
                && this.deviceType.equals(rhs.deviceType)
                && this.networkType.equals(rhs.networkType)
                && this.broadcastType.equals(rhs.broadcastType)
                && this.signalType.equals(rhs.signalType)
                && TextUtils.equals(this.details, rhs.details)
                && TextUtils.equals(this.electricitySources, rhs.electricitySources)
                && TextUtils.equals(this.imageUri, rhs.imageUri);
    }
       
}
