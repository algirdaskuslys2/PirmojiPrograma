package fi.yle.broadcasting.model;

public enum BroadcastType {
    YleBroadcastAudioLive(0),
    YleBroadcastVideoLive(1),
    YleBroadcastAudioRecorded(2),
    YleBroadcastVideoRecorded(3);
    
    private final int value;

    private BroadcastType(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }
    
    public static BroadcastType valueOf(int value) {
        for (BroadcastType bt : BroadcastType.values()) {
            if (bt.value == value) {
                return bt;
            }
        }
        return null;
    }
}
