package fi.yle.broadcasting.model;

import android.content.Context;
import android.content.SharedPreferences;

public class User {
    
    private static final String PREFERENCES_FILE_NAME = "com.yle.broadcasting.User";
    private static final String USERNAME_KEY = "username";
    private static final String PASSWORD_KEY = "password";
    private static final String REMEMBER_ME_KEY = "rememberMe";
    
    private SharedPreferences sharedPrefs;
    
    public User(Context context) {
        this.sharedPrefs = context.getSharedPreferences(User.PREFERENCES_FILE_NAME, Context.MODE_PRIVATE);
    }
    
    public String getPassword() {
        return this.sharedPrefs.getString(PASSWORD_KEY, "");
    }
    
    public void setPassword(String password) {
        this.sharedPrefs.edit().putString(PASSWORD_KEY, password).commit();
    }
    
    public String getUsername() {
        return this.sharedPrefs.getString(USERNAME_KEY, "");
    }
    
    public void setUsername(String username) {
        this.sharedPrefs.edit().putString(USERNAME_KEY, username).commit();
    }
    
    public boolean isRemembered() {
        return this.sharedPrefs.getBoolean(REMEMBER_ME_KEY, false);
    }
    
    public void setRemembered(boolean remembered) {
        this.sharedPrefs.edit().putBoolean(REMEMBER_ME_KEY, remembered).commit();
    }

}
