package fi.yle.broadcasting.model;

public enum NetworkType {
    YleNetworkMobileGate(0),
    YleNetworkInternet(1),
    YleNetworkMobileEth(2),
    YleNetworkEth(3),
    YleNetworkKasat(4),
    YleNetworkViprinet(5),
    YleNetworkExternalLandline(6);
    
    private final int value;

    private NetworkType(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }
    
    public static NetworkType valueOf(int value) {
        for (NetworkType nt : NetworkType.values()) {
            if (nt.value == value) {
                return nt;
            }
        }
        return null;
    }
}
