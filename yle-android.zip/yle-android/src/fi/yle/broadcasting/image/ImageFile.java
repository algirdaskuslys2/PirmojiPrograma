package fi.yle.broadcasting.image;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;

public class ImageFile {

    public enum Format {
        JPG,
        PNG
    }

    public interface OnCancelCallback {
        /**
         * @return true to cancel reading
         */
        public boolean isCanceled();
    }
    
    private ImageFile() {
    }

    public static File createEmptyImage(Context context, Format format) throws IOException {
        File dir = getImagesDir();        
        
        if (!dir.exists()) {
            if (!dir.mkdirs()) {
                throw new IOException("Failed to create images dir");
            }
        }
        
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        
        String imageName = "/IMG_"+ timeStamp;
        String imageExtension = "." + getFormatExtension(format);
        
        File imageFile = new File(dir.getPath() + "/" + imageName + imageExtension);
        int imageFileCount = 0;
        
        while (true) {
            if (!imageFile.createNewFile()) {
                imageFile = new File(dir.getPath() + "/" + imageName + imageFileCount + imageExtension);
                ++imageFileCount;
            } else {
                break;
            }
        }
        
        return imageFile;
    }
    
    public static File createFromUri(Context context, Uri uri) throws IOException {
        File uriFile = getFileFromUri(context, uri);
        Format uriFileFormat = getFileFormat(uriFile);
        
        if (uriFileFormat == null) {
            throw new IOException("Unsupported uri file format");
        }
        
        File newFile = createEmptyImage(context, uriFileFormat);
        
        try {
            copyFileContent(uriFile, newFile);
        } catch (IOException e) {
            if (!newFile.delete()) {
                Log.w("ImageFile", "Failed to delete newFile on exception, file: " + newFile.getName());
            }
            
            throw e;
        }
        
        return newFile;
    }
    
    /**
     * Create image file from input stream.
     * Will close input stream.
     * 
     * @param context
     * @param inputStream   stream to create file from
     * @param format        inputStream image format
     * 
     * @return new file
     * 
     * @throws IOException on failure to create file
     */
    public static File createFromInputStream(Context context, InputStream inputStream, Format format, OnCancelCallback callback) throws IOException {
        if (inputStream == null) {
            throw new IllegalArgumentException("inputStream can not be null");
        }
        
        File newFile = createEmptyImage(context, format);
        
        try {
            copyInputStreamContent(inputStream, newFile, callback);
        } catch (IOException e) {
            if (!newFile.delete()) {
                Log.w("ImageFile", "Failed to delete newFile on exception, file: " + newFile.getName());
            }
            
            throw e;
        }
        
        return newFile;
    }
    
    public static List<File> getImages(Context context) {
        File imagesDir = getImagesDir();
        
        if (!imagesDir.exists()) {
            return new ArrayList<File>();
        }
        
        File[] files = imagesDir.listFiles();
        if (files.length == 0) {
            imagesDir.delete();
            getFilesDir().delete();
        }
        
        
        return Arrays.asList(files);
    }
    
    private static Format getFileFormat(File file) {
        String name = file.getName().toLowerCase(Locale.US);
        if (name.endsWith("jpg") || name.endsWith("jpeg")) {
            return Format.JPG;
        } else if (name.endsWith("png")) {
            return Format.PNG;
        }
        
        return null;
    }
    
    private static String getFormatExtension(Format format) {
        if (format == Format.JPG) {
            return "jpg";
        } else {
            return "png";
        }
    }
    
    private static File getFileFromUri(Context context, Uri uri) throws IOException {
        String[] filePathColumn = { MediaStore.Images.Media.DATA };

        Cursor cursor = context.getContentResolver().query(
                uri, filePathColumn, null, null, null);
        
        if (cursor == null) {
            throw new IOException("Uri do not contain file path entry");
        }
        
        try {
            if (!cursor.moveToFirst()) {
                throw new IOException("No file path entries found");
            }
    
            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
            if (columnIndex == -1) {
                throw new IOException("No file path entries found");
            }
            
            String filePath = cursor.getString(columnIndex);
            return new File(filePath);
        } finally {
            cursor.close();
        }
    }
    
    private static void copyFileContent(File source, File destination) throws IOException {
        FileInputStream fis = new FileInputStream(source);
        BufferedInputStream bis = new BufferedInputStream(fis);
        
        copyInputStreamContent(bis, destination, null);
    }
    
    /**
     * Will always close source stream.
     * @throws IOException on failure to: read source, write to destination file or cancel. 
     */
    private static void copyInputStreamContent(InputStream source, File destination, OnCancelCallback callback) throws IOException {
        BufferedOutputStream bos = null;
        
        try {
            FileOutputStream fos = new FileOutputStream(destination, false);
            
            bos = new BufferedOutputStream(fos);
            
            byte[] buffer = new byte[1024];
            int bytesRead = -1;
            
            while ((bytesRead = source.read(buffer)) != -1) {
                if (callback != null && callback.isCanceled()) {
                    throw new IOException("Canceled");
                }
                
                bos.write(buffer, 0, bytesRead);
            }
        } finally {
            if (bos != null) {
                try {
                    bos.close();
                } catch (IOException e) {
                }
            }
            
            try {
                source.close();
            } catch (IOException e) {
            }
        }
    }
    
    private static File getFilesDir() {
        return new File(Environment.getExternalStorageDirectory().getPath() + "/Yle");
    }
    
    private static File getImagesDir() {
        return new File(getFilesDir().getPath() + "/images");
    }
    
}
