package fi.yle.broadcasting;

import android.app.Application;
import fi.yle.broadcasting.model.User;
import fi.yle.broadcasting.storage.Storage;

public class YleApplication extends Application {
    
    @Override
    public void onCreate() {
        super.onCreate();
        
        User user = new User(this);
        Storage storage = new Storage(this);
        LocationCloudUploader cloudUploader = new LocationCloudUploader(this, storage);
        
        Yle.init(user, storage, cloudUploader);
        Yle.clearImages(this);
    }

}
