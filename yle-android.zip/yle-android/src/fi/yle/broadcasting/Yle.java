package fi.yle.broadcasting;

import java.io.File;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import android.content.Context;
import android.util.Log;
import fi.yle.broadcasting.image.ImageFile;
import fi.yle.broadcasting.model.Location;
import fi.yle.broadcasting.model.User;
import fi.yle.broadcasting.storage.Storage;
import fi.yle.broadcasting.storage.StorageIOException;

public final class Yle {

    private static Yle instance = null;
    
    private User user;
    private Storage storage;
    private LocationCloudUploader cloudUploader;
    
    
    public static synchronized void init(User user, Storage storage, LocationCloudUploader cloudUploader) {
        if (Yle.instance != null) {
            throw new RuntimeException("Already initialized");
        }
        
        Yle.instance = new Yle(user, storage, cloudUploader);
    }
    
    private Yle(User user, Storage storage, LocationCloudUploader cloudUploader) {
        this.user = user;
        this.storage = storage;
        this.cloudUploader = cloudUploader;
    }
    
    public static User getUser() {
        return Yle.instance.user;
    }
    
    public static Storage getStorage() {
        return Yle.instance.storage;
    }
    
    public static LocationCloudUploader getCloudUploader() {
        return Yle.instance.cloudUploader;
    }
    
    /**
     * Removes unused images.
     */
    public static void clearImages(Context context) {
        List<Location> storedLocations;
        
        try {
            storedLocations = getStorage().getAllLocations();
        } catch (StorageIOException e) {
            e.printStackTrace();
            return;
        }
        
        List<File> imageFiles = ImageFile.getImages(context);
        Set<File> locationImageFiles = new TreeSet<File>();
        
        for (Location location : storedLocations) {
            File file = new File(location.getDetails().getImageUri());
            
            if (file.exists()) {
                locationImageFiles.add(file);
            }
        }
        
        for (File file : imageFiles) {
            if (!locationImageFiles.contains(file)) {
                if (!file.delete()) {
                    Log.w("Yle", "Failed to delete unused image file: " + file.getName());
                }
            }
        }
    }
    
}
