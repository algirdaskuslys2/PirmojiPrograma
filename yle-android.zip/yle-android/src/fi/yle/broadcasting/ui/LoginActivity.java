package fi.yle.broadcasting.ui;

//import net.hockeyapp.android.CrashManager;
//import net.hockeyapp.android.UpdateManager;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import fi.yle.broadcasting.R;

public class LoginActivity extends FragmentActivity {

    public static final String EXTRA_FINISH_ON_LOGIN = "fi.yle.broadcasting.ui.LoginActivity.extra.FINISH_ON_LOGIN";
    
    //private static final String HOCKEY_APP_TOKEN = "34afad407bc9a0ed84c8d6eb3c181300";
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        
        Fragment loginFragment = getSupportFragmentManager().findFragmentByTag(LoginFragment.TAG);
        
        if (loginFragment == null) {
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            transaction.add(R.id.container, LoginFragment.newInstance(isFinishOnLoginSet()), LoginFragment.TAG);
            transaction.commit();
        }        
        
        checkForUpdates();
    }
    
    @Override
    public void onResume() {
        super.onResume();
        checkForCrashes();
    }
      
    private void checkForCrashes() {
        //CrashManager.register(this, HOCKEY_APP_TOKEN);
      }

    private void checkForUpdates() {
        // Remove this for store builds!
        //UpdateManager.register(this, HOCKEY_APP_TOKEN);
    }
    
    private boolean isFinishOnLoginSet() {
        Intent intent = getIntent();
        if (intent == null) {
            return false;
        }
        
        return intent.getBooleanExtra(EXTRA_FINISH_ON_LOGIN, false);
    }
}
