package fi.yle.broadcasting.ui;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Point;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import fi.yle.broadcasting.BitmapLoader;
import fi.yle.broadcasting.R;
import fi.yle.broadcasting.Yle;
import fi.yle.broadcasting.image.ImageFile;
import fi.yle.broadcasting.image.ImageFile.Format;
import fi.yle.broadcasting.model.BroadcastType;
import fi.yle.broadcasting.model.DeviceType;
import fi.yle.broadcasting.model.Location;
import fi.yle.broadcasting.model.LocationDetails;
import fi.yle.broadcasting.model.NetworkType;
import fi.yle.broadcasting.model.SignalType;
import fi.yle.broadcasting.storage.StorageIOException;

public class LocationFragment extends Fragment {
    
    public static final String TAG = "fi.yle.broadcasting.ui.LocationFragment.TAG";
    
    /**
     * Location's id which data must be loaded by fragment
     */
    private static final String EXTRA_CLOUD_LOCATION_ID = "fi.yle.broadcasting.ui.LocationFragment.extra.CLOUD_LOCATION_ID";
    
    /**
     * New location latitude.
     * Both latitude and longitude extras must be provided if location id is not set. 
     */
    private static final String EXTRA_LATITUDE = "fi.yle.broadcasting.ui.LocationFragment.extra.LATITUDE";
    
    /**
     * New location longitude.
     * Both latitude and longitude extras must be provided if location id is not set.
     */
    private static final String EXTRA_LONGITUDE = "fi.yle.broadcasting.ui.LocationFragment.extra.LONGITUDE";
    
    private static final int IMAGE_HEIGHT_DP = 150;
    
    private static final int MAX_IMAGE_SIZE = 1024 * 1024 * 10; // 10Mb

    private static final int CAMERA_IMAGE_REQUEST_CODE = 65536;
    private static final int GALLERY_IMAGE_REQUEST_CODE = 65537;
    public static final int MEDIA_TYPE_IMAGE = 1;
    
        
    private Button btnNoSignal, btnAverage, btnGood;
    
    private View savingStatusView;
    private View loadingStatusView;
    
    private Location initialLocation;
    
    private View locationFormView;
    
    private Button saveBtn;
    
    private Spinner deviceTypeSpinner, networkTypeSpinner, broadcastedTypeSpinner;
    private EditText locationNameEditText, placeDetailsEditText, electricitySourceEditText;
    
    private interface CreateInitialLocationCallback {
       
        public void onSuccess();
        
    }
    
    private ImageView image;
    private ImageView imageAdd;
        
    private TextView imageAddText;
    
    private BitmapLoader bitmapLoader = null;
    
    private String imageUri = null;
    private File cameraImageFile = null;

    public static LocationFragment newInstance(String cloudLocationId) throws IllegalArgumentException {
        
        if (cloudLocationId == null) {
            throw new IllegalArgumentException("locationId can't be null");
        }
        
        LocationFragment locationFragment = new LocationFragment();
        
        Bundle args = new Bundle();
        
        args.putString(EXTRA_CLOUD_LOCATION_ID, cloudLocationId);
        
        locationFragment.setArguments(args);
        
        return locationFragment;
    }
    
    public static LocationFragment newInstance(double latitude, double longitude) {
        
        LocationFragment locationFragment = new LocationFragment();
        
        Bundle args = new Bundle();
        
        args.putDouble(EXTRA_LATITUDE, latitude);
        args.putDouble(EXTRA_LONGITUDE, longitude);
        
        locationFragment.setArguments(args);
        
        return locationFragment;
    }
    
    /**
     * Creates initial location.
     * 
     * @param bundle fragment arguments
     * @param callback callback to be invoked once location is created
     */
    private void createInitialLocation(Bundle bundle, final CreateInitialLocationCallback callback) {
        String locationId = bundle.getString(EXTRA_CLOUD_LOCATION_ID);
        
        // new location
        if (locationId == null) {
            final double notFound = -999;
            
            double latitude = bundle.getDouble(EXTRA_LATITUDE, notFound);
            double longitude = bundle.getDouble(EXTRA_LONGITUDE, notFound);
            
            if (latitude == notFound || longitude == notFound) {
                throw new IllegalStateException("latitude and longitude extras must be set for new location");
            }
            
            this.initialLocation =
                    new Location(
                        null,
                        null,
                        "",
                        new LocationDetails(
                                longitude, latitude,
                                DeviceType.YleDeviceMobilePhone, 
                                NetworkType.YleNetworkMobileGate, 
                                BroadcastType.YleBroadcastAudioLive, 
                                SignalType.YleMeasurementSignalNone, 
                                "", "",
                                ""));
            
            callback.onSuccess();
        } 
    }
    
    private boolean isInitialLocationNew() {
        return this.initialLocation.getCloudId() == null;
    }
    
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {

        final View view = inflater.inflate(R.layout.fragment_location, container, false);
        
        this.savingStatusView = view.findViewById(R.id.save_status);
        this.loadingStatusView = view.findViewById(R.id.load_status);
        
        this.locationFormView = view.findViewById(R.id.scroll_view);
        
        this.image = (ImageView) view.findViewById(R.id.image);
        this.imageAdd = (ImageView) view.findViewById(R.id.image_add);
        this.imageAddText = (TextView) view.findViewById(R.id.image_add_text);

        FrameLayout imageLayout = (FrameLayout) view.findViewById(R.id.image_layout);
        
        imageLayout.setOnClickListener(new OnClickListener() {
            
            @Override
            public void onClick(View v) {
                showImagePickingDialog();
            }
        });
        
        this.saveBtn = (Button) view.findViewById(R.id.button_save);
        
        this.locationNameEditText = (EditText) view.findViewById(R.id.location_name);
        
        this.deviceTypeSpinner = (Spinner) view.findViewById(R.id.spinner_device);
        this.networkTypeSpinner = (Spinner) view.findViewById(R.id.spinner_network);
        this.broadcastedTypeSpinner = (Spinner) view.findViewById(R.id.spinner_broadcasted);

        this.placeDetailsEditText = (EditText) view.findViewById(R.id.place_details);
        this.electricitySourceEditText = (EditText) view.findViewById(R.id.electricity_sources);
        
        showProgress(true);
        
        createInitialLocation(getArguments(), new CreateInitialLocationCallback() {
            
            @Override
            public void onSuccess() {
                EditText nametext = (EditText) view.findViewById(R.id.location_name);
                nametext.setText(LocationFragment.this.initialLocation.getName());
                
                setupSpinners(view);
                setupAdditionalInfo(view);
                setupButtons(view);
                
                showProgress(false);
            }
            
        });

        this.saveBtn.setOnClickListener(new OnClickListener() {
            
            @Override
            public void onClick(View v) {
                
                onSaveBtnClicked();
            }
        
        });
        
        return view;
    }
        
    private void onSaveBtnClicked() {
        
        String name = LocationFragment.this.locationNameEditText.getText().toString();
        
        boolean cancel = false;
        View focusView = null;

        if (TextUtils.isEmpty(name)) {
           locationNameEditText.setError(getString(R.string.error_field_required));
           focusView = locationNameEditText;
           cancel = true;
        }
        
        if (cancel) {
            // There was an error; don't attempt save and focus
            // form field with an error.
            focusView.requestFocus();
        } else {
            showProgress(true);
            
            Location location = createLocation();
            
            try {
                Yle.getCloudUploader().enqueueLocation(location);
                getActivity().finish();
            } catch (StorageIOException e) {
                e.printStackTrace();
                showLocationSaveFailureToStorageDialog();
            } finally {
                showProgress(false);
            }
        }

    }
    
    private SignalType getSignalType() {
        
        if (this.btnAverage.isSelected()) {
            return SignalType.YleMeasurementSignalAverage;
        } else if (this.btnGood.isSelected()) {
            return SignalType.YleMeasurementSignalGood;
        }
        
        return SignalType.YleMeasurementSignalNone;
    }

    private void updateButtonsState(View v){
        this.btnNoSignal.setSelected(false);
        this.btnAverage.setSelected(false);
        this.btnGood.setSelected(false);

        v.setSelected(true);
    }
    
    private void setupButtons(View view) {

        this.btnNoSignal = (Button) view.findViewById(R.id.button_no_signal);
        this.btnAverage = (Button) view.findViewById(R.id.button_average);
        this.btnGood = (Button) view.findViewById(R.id.button_good);

        if (LocationFragment.this.initialLocation != null) {
            
            switch (LocationFragment.this.initialLocation.getDetails().getSignalType()) {
            case YleMeasurementSignalNone:
                this.btnNoSignal.setSelected(true);
                break;
            case YleMeasurementSignalAverage:
                this.btnAverage.setSelected(true);
                break;
            case YleMeasurementSignalGood:
                this.btnGood.setSelected(true);
                break;
            }
            
        } else {
            // by default on new location creation
            this.btnNoSignal.setSelected(true);
        }
        
        this.btnNoSignal.setOnClickListener(new OnClickListener() {
            
            @Override
            public void onClick(View v) {
                updateButtonsState(v);
            }
        });
        
        this.btnAverage.setOnClickListener(new OnClickListener() {
            
            @Override
            public void onClick(View v) {
                updateButtonsState(v);
            }
        });

        this.btnGood.setOnClickListener(new OnClickListener() {
            
            @Override
            public void onClick(View v) {
                updateButtonsState(v);
            }
        });
    }
    
    private void setupAdditionalInfo(View view) {
        
        CheckBox checkboxAddInfo = (CheckBox) view.findViewById(R.id.checkbox_additional_info);
        
        final LinearLayout layoutAdditionInfo = (LinearLayout) view.findViewById(R.id.layout_additional_info);
        layoutAdditionInfo.setVisibility(View.GONE);
        
        final ScrollView scrollView = (ScrollView) view.findViewById(R.id.scroll_view);
        
        final EditText detailsText = (EditText) view.findViewById(R.id.place_details);
        final EditText electricityText = (EditText) view.findViewById(R.id.electricity_sources);

        if (isAdditionalInfoAvailable(this.initialLocation)) {
            checkboxAddInfo.setChecked(true);
            layoutAdditionInfo.setVisibility(View.VISIBLE);
            detailsText.setText(this.initialLocation.getDetails().getDetails());
            electricityText.setText(this.initialLocation.getDetails().getElectricitySources());
            
            if (this.initialLocation.getDetails().getImageUri() != null) {
                if (this.imageUri == null) {
                    this.imageUri = this.initialLocation.getDetails().getImageUri();
                }
            }
            
            if (this.imageUri != null) { 
                loadLocationImage();
            }
        }

        checkboxAddInfo.setOnClickListener(new OnClickListener() {
     
            @Override
            public void onClick(View v) {
                if (((CheckBox) v).isChecked()) {

                    layoutAdditionInfo.setVisibility(View.VISIBLE);

                    scrollView.post(new Runnable() {
                        @Override
                        public void run() {
                            scrollView.smoothScrollTo(0, scrollView.getBottom()/2 );
                        }
                    });
                    
                } else {
                    layoutAdditionInfo.setVisibility(View.GONE);
                }
            }
        });

    }
    
    private void loadLocationImage() {
        if (this.bitmapLoader != null) {
            this.bitmapLoader.cancel();
        }
        
        showImageLoadingProgress(true);
        
        int maxImageWidth = getMaxImageWidth();
        int maxImageHeight = getMaxImageHeight();
        
        this.bitmapLoader = new BitmapLoader(this.imageUri, maxImageWidth, maxImageHeight);
        this.bitmapLoader.loadBitmap(new BitmapLoader.OnBitmapLoadedCallback() {
            
            @Override
            public void onSuccess(Bitmap bitmap) {
                Bitmap bitmapImageThumbnail = ThumbnailUtils.extractThumbnail(bitmap,
                        LocationFragment.this.image.getWidth(), LocationFragment.this.image.getHeight());
                
                bitmap.recycle();
                
                LocationFragment.this.image.setImageBitmap(bitmapImageThumbnail);
                
                showImageLoadingProgress(false);
            }
            
            @Override
            public void onFailure(IOException error) {
                showImageLoadingProgress(false);
                Toast.makeText(getActivity(), "Failed to load image", Toast.LENGTH_LONG).show();
            }
        });
    }
    
    
    private boolean isAdditionalInfoAvailable(Location location) {
        return !location.getDetails().getDetails().isEmpty()
                || !location.getDetails().getElectricitySources().isEmpty() 
                || !TextUtils.isEmpty(location.getDetails().getImageUri());
    }
    
    private static List<DeviceType> getDeviceTypes() {
        ArrayList<DeviceType> result = new ArrayList<DeviceType>();
       
        result.add(DeviceType.YleDeviceMobilePhone);
        result.add(DeviceType.YleDevicePortableVideo);
        result.add(DeviceType.YleDeviceNormalVehicle);
        result.add(DeviceType.YleDeviceHeavyDutyVehicle);
       
        return result;
    }
    
    private static List<NetworkType> getNetworkTypes(DeviceType deviceType) {
        ArrayList<NetworkType> result = new ArrayList<NetworkType>();
        
        switch (deviceType) {
        case YleDeviceMobilePhone:
            result.add(NetworkType.YleNetworkMobileGate);
            result.add(NetworkType.YleNetworkInternet);
            break;
            
        case YleDevicePortableVideo:
            result.add(NetworkType.YleNetworkMobileEth);
            result.add(NetworkType.YleNetworkEth);
            break;
            
        case YleDeviceNormalVehicle:
            result.add(NetworkType.YleNetworkViprinet);
            break;
            
        case YleDeviceHeavyDutyVehicle:
            result.add(NetworkType.YleNetworkKasat);
            result.add(NetworkType.YleNetworkViprinet);
            result.add(NetworkType.YleNetworkExternalLandline);
            break;

        }
        
        return result;
    }
    
    private static List<BroadcastType> getBroadcastTypes(DeviceType deviceType) {
        ArrayList<BroadcastType> result = new ArrayList<BroadcastType>();
        
        switch (deviceType) {
        case YleDeviceMobilePhone:
            result.add(BroadcastType.YleBroadcastAudioLive);
            result.add(BroadcastType.YleBroadcastAudioRecorded);
            break;

        case YleDevicePortableVideo:
            result.add(BroadcastType.YleBroadcastVideoLive);
            result.add(BroadcastType.YleBroadcastVideoRecorded);
            break;

        case YleDeviceNormalVehicle:
        case YleDeviceHeavyDutyVehicle:
            result.add(BroadcastType.YleBroadcastAudioLive);
            result.add(BroadcastType.YleBroadcastVideoLive);
            result.add(BroadcastType.YleBroadcastAudioRecorded);
            result.add(BroadcastType.YleBroadcastVideoRecorded);
            break;
        }
        
        return result;
    }
    
    private List<String> getNetworkTypeStrings(DeviceType deviceType) {
        
        ArrayList<String> networkTypeList = new ArrayList<String>();
        
        switch (deviceType) {
        case YleDeviceMobilePhone:
            networkTypeList.add(getString(R.string.network_mobile_gate));
            networkTypeList.add(getString(R.string.network_internet));
            break;
        case YleDevicePortableVideo:
            networkTypeList.add(getString(R.string.network_mobile_eth));
            networkTypeList.add(getString(R.string.network_eth));
            break;
        case YleDeviceNormalVehicle:
            networkTypeList.add(getString(R.string.network_viprinet));
            
            break;
        case YleDeviceHeavyDutyVehicle:
            networkTypeList.add(getString(R.string.network_kasat));
            networkTypeList.add(getString(R.string.network_viprinet));
            networkTypeList.add(getString(R.string.network_external_land_line));
            break;
        }
        
        return networkTypeList;
    }
    
    private List<String> getBroadcastTypeStrings(DeviceType deviceType) {
        
        ArrayList<String> broadcastTypeList = new ArrayList<String>();
        
        switch (deviceType) {
        case YleDeviceMobilePhone:
            broadcastTypeList.add(getString(R.string.broadcasted_audio_live));
            broadcastTypeList.add(getString(R.string.broadcasted_audio_recorded));
            break;
        case YleDevicePortableVideo:
            broadcastTypeList.add(getString(R.string.broadcasted_video_live));
            broadcastTypeList.add(getString(R.string.broadcasted_video_recorded));
            break;

        case YleDeviceNormalVehicle:
        case YleDeviceHeavyDutyVehicle:
            broadcastTypeList.add(getString(R.string.broadcasted_audio_live));
            broadcastTypeList.add(getString(R.string.broadcasted_video_live));
            broadcastTypeList.add(getString(R.string.broadcasted_audio_recorded));
            broadcastTypeList.add(getString(R.string.broadcasted_video_recorded));
            break;
        }
        
        return broadcastTypeList;
    }
    
    private List<String> getDeviceTypeStrings() {
        
        ArrayList<String> deviceTypeList = new ArrayList<String>();
        
        deviceTypeList.add(getString(R.string.device_mobile_phone));
        deviceTypeList.add(getString(R.string.device_portable_video));
        deviceTypeList.add(getString(R.string.device_normal_vehicle));
        deviceTypeList.add(getString(R.string.device_heavy_duty_vehicle));
        
        return deviceTypeList;
    }
    
    private void setupSpinners(View view) {

        final List<String> deviceList = getDeviceTypeStrings();
        final List<String> broadcastedList = getBroadcastTypeStrings(LocationFragment.this.initialLocation.getDetails().getDeviceType());        
        final List<String> networkList = getNetworkTypeStrings(LocationFragment.this.initialLocation.getDetails().getDeviceType());

        final Spinner spinnerDevice = (Spinner) view.findViewById(R.id.spinner_device);
        final Spinner spinnerBroadcasted = (Spinner) view.findViewById(R.id.spinner_broadcasted);
        final Spinner spinnerNetwork = (Spinner) view.findViewById(R.id.spinner_network);
                
        final ArrayAdapter<String> spinnerDeviceAdapter = new ArrayAdapter<String>(getActivity(), R.layout.spinner_item, deviceList);
        final ArrayAdapter<String> spinnerBroadcastedAdapter = new ArrayAdapter<String>(getActivity(), R.layout.spinner_item, broadcastedList);
        final ArrayAdapter<String> spinnerNetworkAdapter = new ArrayAdapter<String>(getActivity(), R.layout.spinner_item, networkList);

        spinnerDeviceAdapter.setDropDownViewResource(R.layout.spinner_dropdown_item);
        spinnerBroadcastedAdapter.setDropDownViewResource(R.layout.spinner_dropdown_item);
        spinnerNetworkAdapter.setDropDownViewResource(R.layout.spinner_dropdown_item);
        
        spinnerDevice.setAdapter(spinnerDeviceAdapter);
        spinnerBroadcasted.setAdapter(spinnerBroadcastedAdapter);
        spinnerNetwork.setAdapter(spinnerNetworkAdapter);
        
        
        DeviceType deviceType = LocationFragment.this.initialLocation.getDetails().getDeviceType();
        int deviceTypeIndex = getDeviceTypes().indexOf(deviceType);
        
        NetworkType networkType = LocationFragment.this.initialLocation.getDetails().getNetworkType();
        int networkTypeIndex = getNetworkTypes(deviceType).indexOf(networkType);
        
        BroadcastType broadcastType = LocationFragment.this.initialLocation.getDetails().getBroadcastType();
        int broadcastTypeIndex = getBroadcastTypes(deviceType).indexOf(broadcastType);

        spinnerDevice.setSelection(deviceTypeIndex);
        spinnerNetwork.setSelection(networkTypeIndex);
        spinnerBroadcasted.setSelection(broadcastTypeIndex);

        spinnerDevice.setOnItemSelectedListener(new OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {

                networkList.clear();
                broadcastedList.clear();

                if (pos == DeviceType.YleDeviceMobilePhone.getValue()) {

                    networkList.addAll(getNetworkTypeStrings(DeviceType.YleDeviceMobilePhone));    
                    broadcastedList.addAll(getBroadcastTypeStrings(DeviceType.YleDeviceMobilePhone));
                    
                } else if (pos == DeviceType.YleDevicePortableVideo.getValue()) {
                    
                    networkList.addAll(getNetworkTypeStrings(DeviceType.YleDevicePortableVideo));
                    broadcastedList.addAll(getBroadcastTypeStrings(DeviceType.YleDevicePortableVideo));
                    
                } else if (pos == DeviceType.YleDeviceNormalVehicle.getValue()) {
                    
                    networkList.addAll(getNetworkTypeStrings(DeviceType.YleDeviceNormalVehicle));
                    broadcastedList.addAll(getBroadcastTypeStrings(DeviceType.YleDeviceNormalVehicle));
                    
                } else if (pos == DeviceType.YleDeviceHeavyDutyVehicle.getValue()) {
                    
                    networkList.addAll(getNetworkTypeStrings(DeviceType.YleDeviceHeavyDutyVehicle));
                    broadcastedList.addAll(getBroadcastTypeStrings(DeviceType.YleDeviceHeavyDutyVehicle));
                }
            
                spinnerDeviceAdapter.notifyDataSetChanged();
                spinnerNetworkAdapter.notifyDataSetChanged();
                spinnerBroadcastedAdapter.notifyDataSetChanged();
                
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
            }
        });
        
    }
    
    private void showProgress(boolean show) {
       if (show) {
           LocationFragment.this.locationFormView.setVisibility(View.GONE);
           LocationFragment.this.saveBtn.setVisibility(View.GONE);
           LocationFragment.this.savingStatusView.setVisibility(View.VISIBLE);
       } else {
           LocationFragment.this.savingStatusView.setVisibility(View.GONE);
           LocationFragment.this.locationFormView.setVisibility(View.VISIBLE);
           LocationFragment.this.saveBtn.setVisibility(View.VISIBLE);
       }
    }
    
    private void finishActivity() {
        if (this.bitmapLoader != null) {
            this.bitmapLoader.cancel();
        }
        
        Yle.clearImages(getActivity());
        getActivity().finish();
    }
    
    public void backButtonWasPressed() {
        if (this.initialLocation == null) { // location loading took lot of time and user run out of patience
            finishActivity();
        } else if (!isInitialLocationNew() && this.initialLocation.equals(createLocation()) ) {
            finishActivity();
        } else {
            AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
            builder.setTitle(R.string.save_adding_location_details_title);
            builder.setNegativeButton(R.string.save_adding_location_details_no, null);
            builder.setPositiveButton(R.string.save_adding_location_details_yes, new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {
                    finishActivity();                
                }

            });
            
            builder.setMessage(R.string.save_adding_location_details_message);
            builder.show();
        }
    }
    
    private Location createLocation () {
        
        String name = this.locationNameEditText.getText().toString();
        
        int deviceTypeIndex = this.deviceTypeSpinner.getSelectedItemPosition();
        int networkTypeIndex = this.networkTypeSpinner.getSelectedItemPosition();
        int broadcastedTypeIndex = this.broadcastedTypeSpinner.getSelectedItemPosition();
        
        DeviceType deviceType = getDeviceTypes().get(deviceTypeIndex);
        NetworkType networkType = getNetworkTypes(deviceType).get(networkTypeIndex);
        BroadcastType broadcastType = getBroadcastTypes(deviceType).get(broadcastedTypeIndex);
        
        String details = placeDetailsEditText.getText().toString();
        String electricitySource = electricitySourceEditText.getText().toString();
        
        LocationDetails locationDetails = new LocationDetails(
                this.initialLocation.getDetails().getLongitude(),
                this.initialLocation.getDetails().getLatitude(),
                deviceType, 
                networkType, 
                broadcastType, 
                getSignalType(), 
                details, 
                electricitySource, 
                this.imageUri);

        Location location = new Location(
                this.initialLocation.getStorageId(),
                this.initialLocation.getCloudId(),
                name,
                locationDetails
                );
        
        return location;
    }

    public void onImageResult(int requestCode, int resultCode, 
            Intent imageReturnedIntent) {
        
        boolean success = true;
        int toastMessageRes = R.string.image_failed_capture_image;
        
        if (resultCode == Activity.RESULT_OK) {
            String newImageUri = null;
            
            switch(requestCode) {
                case(GALLERY_IMAGE_REQUEST_CODE):
                    LocationFragment.this.image.setVisibility(View.VISIBLE);
                
                    try {
                        File galleryImageFile = ImageFile.createFromUri(getActivity(), imageReturnedIntent.getData());
                        newImageUri = galleryImageFile.getPath();
                    } catch (IOException e) {
                        e.printStackTrace();
                        success = false;
                    }

                    break;
                case(CAMERA_IMAGE_REQUEST_CODE):
                    LocationFragment.this.image.setVisibility(View.VISIBLE);
                    newImageUri = this.cameraImageFile.getPath();
                    this.cameraImageFile = null;
                    break;
            }
            
            if (newImageUri != null) {
                File imageFile = new File(newImageUri);
                if (imageFile.length() > MAX_IMAGE_SIZE) {
                    success = false;
                    toastMessageRes = R.string.image_failed_size_too_large;
                    imageFile.delete();
                } else {
                    this.imageUri = newImageUri;
                    loadLocationImage();
                }
            }
            
        } else if (resultCode == Activity.RESULT_CANCELED){
            if (this.cameraImageFile != null) {
                this.cameraImageFile.delete();
                this.cameraImageFile = null;
            }
        } 
        
        if (!success) {
            // failed to capture image
            Toast.makeText(getActivity(), getString(toastMessageRes), Toast.LENGTH_SHORT).show();
        }
    }
    
    
    private void showImagePickingDialog() {

        String[] addPhoto = new String[] { 
                getString(R.string.image_use_camera),
                getString(R.string.image_use_gallery),
                getString(R.string.image_remove)
        };
        
        AlertDialog.Builder dialog = new AlertDialog.Builder(getActivity());
        dialog.setTitle(getString(R.string.image_add));
        
        dialog.setItems(addPhoto, new DialogInterface.OnClickListener() {
            
            @Override
            public void onClick(DialogInterface dialog, int id) {

                if (id == 0) { // Call camera Intent
                    
                    Intent takePicture = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    
                    try {
                        LocationFragment.this.cameraImageFile = ImageFile.createEmptyImage(getActivity(), Format.JPG);
                        
                        takePicture.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(LocationFragment.this.cameraImageFile));
                        
                        startActivityForResult(takePicture, 0);
                    } catch (IOException e) {
                        Toast.makeText(getActivity(), R.string.image_failed_create_camera_image, Toast.LENGTH_SHORT).show();
                        e.printStackTrace();
                    }
                }
                if (id == 1) { //call gallery
                    
                    Intent pickPhoto = new Intent(Intent.ACTION_PICK,
                            MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    
                    startActivityForResult(pickPhoto, 1);
                }
                if (id == 2) { //remove item
                    LocationFragment.this.imageUri = "";
                    LocationFragment.this.image.setVisibility(View.GONE);
                }
            }
        });     
        
        dialog.setNeutralButton(getString(R.string.image_cancel), new android.content.DialogInterface.OnClickListener(){
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        
        dialog.show();
    }

    private void showLocationSaveFailureToStorageDialog() {
        AlertDialog.Builder dialog = new AlertDialog.Builder(getActivity());
        dialog.setTitle(getString(R.string.error_dialog_title));
        dialog.setPositiveButton(R.string.error_dialog_ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }

        });
        dialog.setMessage(R.string.storage_location_save_failure);
        dialog.show();
        
    }
    
    private void showImageLoadingProgress(boolean show) {
            if (show) {
                LocationFragment.this.loadingStatusView.setVisibility(View.VISIBLE);
                LocationFragment.this.imageAdd.setVisibility(View.GONE);
                LocationFragment.this.imageAddText.setVisibility(View.GONE);
            } else {
                LocationFragment.this.loadingStatusView.setVisibility(View.GONE);
                LocationFragment.this.imageAdd.setVisibility(View.VISIBLE);
                LocationFragment.this.imageAddText.setVisibility(View.VISIBLE);
            }
    }
    
    private int getMaxImageWidth() {
        Display display = getActivity().getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        int width = size.x;

        return width;
    }
    
    private int getMaxImageHeight() {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, IMAGE_HEIGHT_DP,
                    getActivity().getResources().getDisplayMetrics());
    }
}
