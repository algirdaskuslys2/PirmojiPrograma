package fi.yle.broadcasting.ui;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import fi.yle.broadcasting.R;
import fi.yle.broadcasting.Yle;

/**
 * Activity which displays a login screen to the user
 */
public class LoginFragment extends Fragment {

   public static final String TAG = "fi.yle.broadcasting.ui.LoginFragment.TAG";
   
   private static final String EXTRA_FINISH_ON_LOGIN = "fi.yle.broadcasting.ui.LoginFragment.extra.FINISH_ON_LOGIN";

   // UI references.
   private EditText usernameView;
   private EditText passwordView;
   private View loginFormView;
   private View loginStatusView;
   private CheckBox rememberMeCheckBox;
   private Button loginButton;
   
      
   public static LoginFragment newInstance(boolean finishOnLogin) {
       
       Bundle bundle = new Bundle();
       bundle.putBoolean(EXTRA_FINISH_ON_LOGIN, finishOnLogin);
       
       LoginFragment fragment = new LoginFragment();
       fragment.setArguments(bundle);
       
       return fragment;
   }
   
   @Override
   public View onCreateView(LayoutInflater inflater, ViewGroup container,
         Bundle savedInstanceState) {

      View view = inflater.inflate(R.layout.fragment_login, container, false);
      
      this.usernameView = (EditText) view.findViewById(R.id.username);
      this.passwordView = (EditText) view.findViewById(R.id.password);

      Typeface typeFace = Typeface.createFromAsset(getActivity().getAssets(), getString(R.string.font_museosans));
      this.rememberMeCheckBox = (CheckBox) view.findViewById(R.id.remember_me);
      this.rememberMeCheckBox.setTypeface(typeFace);
      this.rememberMeCheckBox.setTextColor(getResources().getColor(R.color.text_hint));

      this.usernameView.setText(Yle.getUser().getUsername());
      this.passwordView.setText(Yle.getUser().getPassword());
      this.rememberMeCheckBox.setChecked(Yle.getUser().isRemembered());

      this.passwordView
            .setOnEditorActionListener(new TextView.OnEditorActionListener() {
               @Override
               public boolean onEditorAction(TextView textView, int id,
                     KeyEvent keyEvent) {
                  if (id == R.id.login || id == EditorInfo.IME_NULL) {
                     attemptLogin();
                     return true;
                  }
                  return false;
               }
            });
      
      this.loginFormView = view.findViewById(R.id.login_form);
      this.loginStatusView = view.findViewById(R.id.login_status);
      
      this.loginButton = (Button) view.findViewById(R.id.login_button);
      this.loginButton.setTypeface(typeFace);

      this.loginButton.setOnClickListener(
            new View.OnClickListener() {
               @Override
               public void onClick(View view) {
                  attemptLogin();
               }
            });
      
      return view;
   }
   
   /**
    * Attempts to sign in or register the account specified by the login form.
    * If there are form errors the errors are presented and no actual 
    * login attempt is made.
    */
   public void attemptLogin() {

      // Store values at the time of the login attempt.
      final String username = this.usernameView.getText().toString();
      final String password = this.passwordView.getText().toString();
      final boolean isRemembered = this.rememberMeCheckBox.isChecked();

      Yle.getUser().setUsername(username);
      Yle.getUser().setPassword(isRemembered ? password : "");
      Yle.getUser().setRemembered(isRemembered);
      
      // Reset errors.
      this.usernameView.setError(null);
      this.passwordView.setError(null);

      boolean cancel = false;
      View focusView = null;

      // Check for a valid password.
      if (TextUtils.isEmpty(password)) {
         this.passwordView.setError(getString(R.string.error_field_required));
         focusView = passwordView;
         cancel = true;
      }

      // Check for a valid user name.
      if (TextUtils.isEmpty(username)) {
         this.usernameView.setError(getString(R.string.error_field_required));
         focusView = usernameView;
         cancel = true;
      }

      if (cancel) {
         // There was an error; don't attempt login and focus
         // form field with an error.
         focusView.requestFocus();
      } else {
         // Show a progress spinner, and kick off a background task to
         // perform the user login attempt.
         showProgress(true);
  
         if (isFinishOnLoginSet()) {
             getActivity().finish();
         } else {
            Intent intent = new Intent(getActivity(), MapActivity.class);
            startActivity(intent);
         }
       
      }
   }

   /**
    * Shows the progress UI and hides the login form.
    */
   private void showProgress(final boolean show) {
       if (show) {
           LoginFragment.this.loginFormView.setVisibility(View.GONE);
           loginStatusView.setVisibility(View.VISIBLE);
       } else {
           loginStatusView.setVisibility(View.GONE);
           LoginFragment.this.loginFormView.setVisibility(View.VISIBLE);
       }

   }

   private boolean isFinishOnLoginSet() {
       return getArguments().getBoolean(EXTRA_FINISH_ON_LOGIN, false);
   }
   
   @Override
    public void onResume() {
        super.onResume();
        showProgress(false);
    }
}
