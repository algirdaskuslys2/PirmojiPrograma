package fi.yle.broadcasting.ui;

import android.app.ActionBar;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;
import fi.yle.broadcasting.R;

public class LocationActivity extends FragmentActivity {
    
    public static final String EXTRA_CLOUD_LOCATION_ID = "fi.yle.broadcasting.ui.LocationActivity.extra.CLOUD_LOCATION_ID";
    public static final String EXTRA_LATITUDE = "fi.yle.broadcasting.ui.LocationActivity.extra.LATITUDE";
    public static final String EXTRA_LONGITUDE = "fi.yle.broadcasting.ui.LocationActivity.extra.LONGITUDE";
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location);

        if (initLocationFragment(getIntent()) == null) {
            // Can not show location by provided parameters. Closing.
            finish();
        }
        
        ActionBar actionBar = getActionBar();
        actionBar.setDisplayShowCustomEnabled(true);
        actionBar.setDisplayShowHomeEnabled(false);
        actionBar.setIcon(
                new ColorDrawable(getResources().getColor(android.R.color.transparent)));   
        
        View titleView = getLayoutInflater().inflate(R.layout.action_bar_title, null);
        TextView title = (TextView) titleView.findViewById(R.id.title);
        
        titleView.setOnClickListener(new OnClickListener() {
            
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        
        title.setText(R.string.location_activity_label);

        actionBar.setCustomView(titleView);

    }

    private Fragment initLocationFragment(Intent intent) {
        Fragment locationFragment = getSupportFragmentManager().findFragmentByTag(LocationFragment.TAG);
        
        if (intent.hasExtra(EXTRA_CLOUD_LOCATION_ID)) {
            String locationId = intent.getStringExtra(EXTRA_CLOUD_LOCATION_ID);
            locationFragment = LocationFragment.newInstance(locationId);
        } else if (intent.hasExtra(EXTRA_LATITUDE)
                && intent.hasExtra(EXTRA_LONGITUDE)) {
            
            double latitude = intent.getDoubleExtra(EXTRA_LATITUDE, 0.0);
            double longitude = intent.getDoubleExtra(EXTRA_LONGITUDE, 0.0);
            
            locationFragment = LocationFragment.newInstance(latitude, longitude);
        }
        
        if (locationFragment != null) {
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            
            transaction.add(R.id.container, locationFragment, LocationFragment.TAG);
            
            transaction.commit();
        }
        
        return locationFragment;
    }
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
        case android.R.id.home:
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    
    @Override
    public void onBackPressed() {
        
        Fragment locationFragment = getSupportFragmentManager().findFragmentByTag(LocationFragment.TAG);

        if (locationFragment != null) {
            ((LocationFragment)locationFragment).backButtonWasPressed(); 
        }

    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, 
            Intent imageReturnedIntent) {
        Fragment locationFragment = getSupportFragmentManager().findFragmentByTag(LocationFragment.TAG);

        if (locationFragment != null) {
            ((LocationFragment)locationFragment).onImageResult(requestCode, resultCode, imageReturnedIntent); 
        }
    }
    
    /**
     * For hiding keyboard when user is not in location edit text fields.
     * 
     */
    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        View view = getCurrentFocus();
        boolean ret = super.dispatchTouchEvent(event);

        if (view instanceof EditText) {
            View w = getCurrentFocus();
            int scrcoords[] = new int[2];
            w.getLocationOnScreen(scrcoords);
            float x = event.getRawX() + w.getLeft() - scrcoords[0];
            float y = event.getRawY() + w.getTop() - scrcoords[1];

            if (event.getAction() == MotionEvent.ACTION_UP 
                    && (x < w.getLeft() || x >= w.getRight() 
                    || y < w.getTop() || y > w.getBottom()) ) { 
                InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(getWindow().getCurrentFocus().getWindowToken(), 0);
            }
        }
     return ret;
    }
 
}
