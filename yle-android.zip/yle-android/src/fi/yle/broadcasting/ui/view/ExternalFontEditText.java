package fi.yle.broadcasting.ui.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.widget.EditText;

public abstract class ExternalFontEditText extends EditText {

    public abstract String getDefaultFontPath();

    public abstract String getItalicFontPath();

    public abstract String getBoldFontPath();

    public abstract String getBoldItalicFontPath();

    public ExternalFontEditText(Context context) {
        super(context);
        setTypeface(this);
    }

    public ExternalFontEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
        setTypeface(this, attrs);
    }

    public ExternalFontEditText(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        setTypeface(this, attrs);
    }

    public void setTypeface(EditText editText) {
        if (!editText.isInEditMode()) {
            editText.setTypeface(Typeface.createFromAsset(editText.getContext()
                    .getAssets(), getDefaultFontPath()));
        }
    }

    public void setTypeface(EditText editText, AttributeSet attrs) {
        if (!editText.isInEditMode()) {
            int[] attrsArray = new int[] { android.R.attr.textStyle };
            TypedArray ta = editText.getContext().obtainStyledAttributes(attrs,
                    attrsArray);
            int textStyle = ta.getInt(0, -1);
            ta.recycle();

            String font;
            switch (textStyle) {
            case Typeface.ITALIC:
                font = getItalicFontPath();
                break;
            case Typeface.BOLD:
                font = getBoldFontPath();
                break;
            case Typeface.BOLD_ITALIC:
                font = getBoldItalicFontPath();
                break;
            default:
                font = getDefaultFontPath();
                break;
            }

            editText.setTypeface(Typeface.createFromAsset(editText.getContext()
                    .getAssets(), font));
        }
    }

}
