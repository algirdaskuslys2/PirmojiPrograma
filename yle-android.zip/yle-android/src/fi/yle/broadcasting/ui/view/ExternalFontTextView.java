package fi.yle.broadcasting.ui.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.widget.TextView;

public abstract class ExternalFontTextView extends TextView {

    public abstract String getDefaultFontPath();

    public abstract String getItalicFontPath();

    public abstract String getBoldFontPath();

    public abstract String getBoldItalicFontPath();

    public ExternalFontTextView(Context context) {
        super(context);
        setTypeface(this);
    }

    public ExternalFontTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setTypeface(this, attrs);
    }

    public ExternalFontTextView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        setTypeface(this, attrs);
    }

    public void setTypeface(TextView textView) {
        if (!textView.isInEditMode()) {
            textView.setTypeface(Typeface.createFromAsset(textView.getContext()
                    .getAssets(), getDefaultFontPath()));
        }
    }

    public void setTypeface(TextView textView, AttributeSet attrs) {
        if (!textView.isInEditMode()) {
            int[] attrsArray = new int[] { android.R.attr.textStyle };
            TypedArray ta = textView.getContext().obtainStyledAttributes(attrs,
                    attrsArray);
            int textStyle = ta.getInt(0, -1);
            ta.recycle();

            String font;
            switch (textStyle) {
            case Typeface.ITALIC:
                font = getItalicFontPath();
                break;
            case Typeface.BOLD:
                font = getBoldFontPath();
                break;
            case Typeface.BOLD_ITALIC:
                font = getBoldItalicFontPath();
                break;
            default:
                font = getDefaultFontPath();
                break;
            }

            textView.setTypeface(Typeface.createFromAsset(textView.getContext()
                    .getAssets(), font));
        }
    }

}
