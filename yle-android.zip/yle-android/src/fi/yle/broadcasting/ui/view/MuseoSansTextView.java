package fi.yle.broadcasting.ui.view;

import android.content.Context;
import android.util.AttributeSet;
import fi.yle.broadcasting.R;

public class MuseoSansTextView extends ExternalFontTextView {

    public MuseoSansTextView(Context context) {
        super(context);
    }

    public MuseoSansTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public MuseoSansTextView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    @Override
    public String getDefaultFontPath() {
        return getContext().getString(R.string.font_museosans);
    }

    @Override
    public String getItalicFontPath() {
        return getDefaultFontPath();
    }

    @Override
    public String getBoldFontPath() {
        return getDefaultFontPath();
    }

    @Override
    public String getBoldItalicFontPath() {
        return getDefaultFontPath();
    }

}
