package fi.yle.broadcasting.ui;

import java.util.List;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.SearchView;
import android.widget.SearchView.OnQueryTextListener;
import android.widget.TextView;
import fi.yle.broadcasting.R;
import fi.yle.broadcasting.model.Location;


public class SearchFragment extends Fragment{
    
    public static final String TAG = "fi.yle.broadcasting.ui.SearchFragment.TAG";
    
    private List<Location> locationList;
    private ViewGroup locationGroup;
    
    private View searchStatusView;
    private View searchFormView;
    
    private SearchView searchView;
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
    
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        
        final View view = inflater.inflate(R.layout.fragment_search, container, false);
        
        this.searchStatusView = view.findViewById(R.id.search_status);
        this.searchFormView = view.findViewById(R.id.search_form);
        
        this.searchView = (SearchView) view.findViewById(R.id.search_view);
        this.searchView.setVisibility(View.GONE);
        
        Button searchBtn = (Button) view.findViewById(R.id.search_button);
        Typeface typeFace = Typeface.createFromAsset(getActivity().getAssets(), getString(R.string.font_museosans));
        searchBtn.setTypeface(typeFace);
        searchBtn.setText(getString(R.string.search_saved_locations));
        
        searchBtn.setTextSize(TypedValue.COMPLEX_UNIT_PX, getResources().getDimension(R.dimen.font_size_extra_small));
        searchBtn.setTextColor(getResources().getColor(R.color.text_hint));

        searchBtn.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                v.setVisibility(View.GONE);
                SearchFragment.this.searchView.setVisibility(View.VISIBLE);
                SearchFragment.this.searchView.onActionViewExpanded();
            }
        });
        
        AutoCompleteTextView searchText = (AutoCompleteTextView) this.searchView.findViewById(
                this.searchView.getContext().getResources().getIdentifier("android:id/search_src_text", null, null));
        searchText.setTextSize(TypedValue.COMPLEX_UNIT_PX, 
                getResources().getDimensionPixelSize(R.dimen.font_size_extra_small));
        
        this.searchView.setOnQueryTextListener(new OnQueryTextListener() {
            
            @Override
            public boolean onQueryTextSubmit(String location) {

                view.clearFocus();
                
                return false;
            }

            @Override
            public boolean onQueryTextChange(String location) {

                searchLocations(location);

                return false;
            }
        });
        
        return view;
    }

    private void updateLocations(View view) {
        
        this.locationGroup = (ViewGroup) view
                .findViewById(R.id.saved_locations_container);
        this.locationGroup.removeAllViews();
        
        for (Location location : SearchFragment.this.locationList) {
            final View locationItem = getActivity().getLayoutInflater().inflate(
                    R.layout.location_item, SearchFragment.this.locationGroup, false);
            final TextView title = (TextView) locationItem.findViewById(R.id.title);
            title.setText(location.getName());
            final String cloudLocationId = location.getCloudId(); 
            title.setOnClickListener(new OnClickListener() {
                
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(getActivity(), LocationActivity.class);
                    intent.putExtra(LocationActivity.EXTRA_CLOUD_LOCATION_ID, cloudLocationId);
                    startActivity(intent);
                    
                }
            });
            this.locationGroup.addView(locationItem);
        }
    }
    
    private void searchLocations(String searchKey) {
        showProgress(true);
        updateLocations(getView());
    }

    @Override
    public void onResume() {
        super.onResume();
        searchLocations(this.searchView.getQuery().toString());
    }
    
    private void showProgress(final boolean show) {
         if (show) {
             SearchFragment.this.searchFormView.setVisibility(View.GONE);
             SearchFragment.this.searchStatusView.setVisibility(View.VISIBLE);
         } else {
             SearchFragment.this.searchStatusView.setVisibility(View.GONE);
             SearchFragment.this.searchFormView.setVisibility(View.VISIBLE);
         }
    }

}
