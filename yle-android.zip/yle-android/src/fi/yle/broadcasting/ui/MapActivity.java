package fi.yle.broadcasting.ui;

import android.app.ActionBar;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Typeface;
import android.location.Location;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.util.TypedValue;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.OnMyLocationChangeListener;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import fi.yle.broadcasting.LocationUploadViewController;
import fi.yle.broadcasting.R;
import fi.yle.broadcasting.Yle;

public class MapActivity extends FragmentActivity {

    private static final int ZOOM_TIMES_FOR_CAMERA = 17;
    
    private GoogleMap googleMap;
    
    private LocationUploadViewController uploadController = null;
    
    private View refreshView = null;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
    	
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);
        
        ActionBar actionBar = getActionBar();
        actionBar.setLogo(R.drawable.icon_kuski);
        
        Button searchBtn = (Button) findViewById(R.id.search_button);
        Typeface typeFace = Typeface.createFromAsset(getAssets(), getString(R.string.font_museosans));
        searchBtn.setTypeface(typeFace);
        searchBtn.setText(getString(R.string.search_saved_locations));
        
        searchBtn.setTextSize(TypedValue.COMPLEX_UNIT_PX, getResources().getDimension(R.dimen.font_size_extra_small));
        searchBtn.setTextColor(getResources().getColor(R.color.text_hint));
        
        searchBtn.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(MapActivity.this, SearchActivity.class);
                startActivity(intent);
            }
        });
        
        final Button newLocationBtn = (Button) findViewById(R.id.new_location_button);
        typeFace = Typeface.createFromAsset(getAssets(), getString(R.string.font_museosans));
        newLocationBtn.setTypeface(typeFace);
        newLocationBtn.setText(getString(R.string.new_location));
        
        newLocationBtn.setTextSize(TypedValue.COMPLEX_UNIT_PX, getResources().getDimension(R.dimen.font_size_extra_small));
        newLocationBtn.setTextColor(getResources().getColor(R.color.text_hint));
        
        newLocationBtn.setEnabled(false);
        newLocationBtn.setCompoundDrawablesWithIntrinsicBounds(R.drawable.icon_new_location_disabled, 0, 0, 0);
        
        newLocationBtn.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(MapActivity.this, LocationActivity.class);
                intent.putExtra(LocationActivity.EXTRA_LATITUDE, MapActivity.this.googleMap.getMyLocation().getLatitude());
                intent.putExtra(LocationActivity.EXTRA_LONGITUDE, MapActivity.this.googleMap.getMyLocation().getLongitude());
                startActivity(intent);
            }
        });
        
        int status = GooglePlayServicesUtil.isGooglePlayServicesAvailable(this);
        
        if (status != ConnectionResult.SUCCESS) {
            int requestCode = 10;
            Dialog dialog = GooglePlayServicesUtil.getErrorDialog(status, this, requestCode);
            dialog.show();
        } else {
            SupportMapFragment fm = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
            
            this.googleMap = fm.getMap();
            
            this.googleMap.setMyLocationEnabled(true);
            
            Location myLocation = this.googleMap.getMyLocation();
            LatLng latLng = new LatLng(
                    Double.parseDouble(getString(R.string.default_location_latitude)),
                    Double.parseDouble(getString(R.string.default_location_longitude)));
            
            if (myLocation == null) {
                this.googleMap.setOnMyLocationChangeListener(new OnMyLocationChangeListener() {
                    
                    @Override
                    public void onMyLocationChange(Location location) {
                        newLocationBtn.setEnabled(true);
                        newLocationBtn.setCompoundDrawablesWithIntrinsicBounds(R.drawable.icon_new_location_enabled, 0, 0, 0);
                        zoomToLocation(new LatLng(location.getLatitude(), location.getLongitude()), ZOOM_TIMES_FOR_CAMERA, true);
                        MapActivity.this.googleMap.setOnMyLocationChangeListener(null);
                    }
                });
            } else {
                latLng = new LatLng(myLocation.getLatitude(), myLocation.getLongitude());
            }
            
            zoomToLocation(latLng, 3, false);
        }
    }
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        
        getMenuInflater().inflate(R.menu.map, menu);
        
        this.refreshView = menu.findItem(R.id.refresh).getActionView();
        
        this.uploadController = new LocationUploadViewController(this, Yle.getCloudUploader(), this.refreshView);
        registerMenu();

        return true;
    }
    
    private void zoomToLocation(LatLng latLng, int zoomLevel, boolean animate) {
        CameraUpdate center = CameraUpdateFactory.newLatLng(latLng);
        CameraUpdate zoom = CameraUpdateFactory.zoomTo(zoomLevel);
        
        this.googleMap.moveCamera(center);
        
        if (animate) {
            this.googleMap.animateCamera(zoom);
        } else {
            this.googleMap.moveCamera(zoom);
        }
    }
    
    @Override
    protected void onResume() {
        super.onResume();
        registerMenu();

    }
    
    @Override
    protected void onPause() {
        super.onPause();
        unregisterMenu();
    }
    
    private void registerMenu() {
        if (this.refreshView != null) {
            this.uploadController.register();
        }
    }
    
    private void unregisterMenu() {
        if (this.refreshView != null) {
            this.uploadController.unregister();
        }
    }

}
 