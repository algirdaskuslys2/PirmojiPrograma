package fi.yle.broadcasting.ui;

import android.app.ActionBar;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;
import fi.yle.broadcasting.LocationUploadViewController;
import fi.yle.broadcasting.R;
import fi.yle.broadcasting.Yle;

public class SearchActivity extends FragmentActivity {

    private LocationUploadViewController uploadController = null;
    
    private View refreshView = null;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        
        Fragment searchFragment = getSupportFragmentManager().findFragmentByTag(SearchFragment.TAG);
        
        if (searchFragment == null) {
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            transaction.add(R.id.container, new SearchFragment(), SearchFragment.TAG);
            transaction.commit();
        }   
        
        ActionBar actionBar = getActionBar();
        actionBar.setDisplayShowCustomEnabled(true);
        actionBar.setDisplayShowHomeEnabled(false);
        actionBar.setIcon(
                new ColorDrawable(getResources().getColor(android.R.color.transparent)));   
        
        View titleView = getLayoutInflater().inflate(R.layout.action_bar_title, null);
        TextView title = (TextView) titleView.findViewById(R.id.title);
        
        titleView.setOnClickListener(new OnClickListener() {
            
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        
        
        title.setText(R.string.search_activity_label);

        actionBar.setCustomView(titleView);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.

        getMenuInflater().inflate(R.menu.search, menu);
        
        this.refreshView = menu.findItem(R.id.refresh).getActionView();
        this.uploadController = new LocationUploadViewController(this, Yle.getCloudUploader(), this.refreshView);
        registerMenu();
        
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
        case android.R.id.home:
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    
    @Override
    protected void onResume() {
        super.onResume();
        
        registerMenu();
    }
    
    @Override
    protected void onPause() {
        super.onPause();
        
        unregisterMenu();
    }
    
    private void registerMenu() {
        if (this.refreshView != null) {
            this.uploadController.register();
        }
    }
    
    private void unregisterMenu() {
        if (this.refreshView != null) {
            this.uploadController.unregister();
        }
    }

}
