package fi.yle.broadcasting;

import java.util.List;

import android.content.Context;
import android.content.Intent;
import fi.yle.broadcasting.model.Location;
import fi.yle.broadcasting.storage.Storage;
import fi.yle.broadcasting.storage.StorageIOException;

public final class LocationCloudUploader {

    public static final String ACTION_LOCATION_UPLOADING_DID_START = "fi.yle.broadcasting.LocationUploadManager.action.LOCATION_UPLOADING_DID_START";
    public static final String ACTION_LOCATION_UPLOADING_DID_FINISH = "fi.yle.broadcasting.LocationUploadManager.action.LOCATION_UPLOADING_DID_FINISH";
    public static final String ACTION_SAVED_LOCATION_COUNT_DID_CHANGE = "fi.yle.broadcasting.LocationUploadManager.action.SAVED_LOCATION_COUNT_DID_CHANGE";
    public static final String EXTRA_ERROR = "fi.yle.broadcasting.LocationUploadManager.extra.ERROR";
    
    private Context context;
    private Storage storage;
    private boolean isUploading;
    
    public enum Error {
        NO_ERROR,
        LOCATION_DELETE_FAILED,
        LOCATION_GET_FAILED,
        CLOUD_FAILURE
    }
    
    public LocationCloudUploader(Context context, Storage storage) {
        this.context = context;
        this.storage = storage;
        this.isUploading = false;
    }
    
    public void enqueueLocation(Location location) throws StorageIOException {
        saveLocation(location);
        uploadLocations();
    }
    
    public void uploadLocations() {
        if (isUploadingLocations()) {
            return;
        }
        
        uploadNextLocation();
    }
    
    public boolean isUploadingLocations() {
        return this.isUploading;
    }
    
    public long getSavedLocationCount() throws StorageIOException {
        return this.storage.getLocationCount();
    }
    
    private void uploadNextLocation() {
        try {
            List<Location> savedLocations = this.storage.getAllLocations();
            
            if (savedLocations.size() == 0) {
                return;
            }

            Location locationToSend = savedLocations.get(0);
            uploadLocation(locationToSend);

        } catch (StorageIOException e) {
            notifyUploadStarted();
            notifyUploadFinished(Error.LOCATION_GET_FAILED);
        }
    }
    
    private void uploadLocation(final Location location) {
         notifyUploadStarted();
    }
    
    private void saveLocation(Location location) throws StorageIOException {
        this.storage.saveLocation(location);
        notifyLocationCountChanged();
    }
    
    private void notifyUploadFinished(Error error) {
        this.isUploading = false;
        
        Intent intent = new Intent(ACTION_LOCATION_UPLOADING_DID_FINISH);
        intent.putExtra(EXTRA_ERROR, error);
        
        this.context.sendBroadcast(intent);
    }
    
    private void notifyUploadStarted() {
        this.isUploading = true;
        this.context.sendBroadcast(new Intent(ACTION_LOCATION_UPLOADING_DID_START));
    }
    
    private void notifyLocationCountChanged() {
        this.context.sendBroadcast(new Intent(ACTION_SAVED_LOCATION_COUNT_DID_CHANGE));
    }
    
}
 