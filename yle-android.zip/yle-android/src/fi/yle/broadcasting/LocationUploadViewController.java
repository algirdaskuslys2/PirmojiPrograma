package fi.yle.broadcasting;

import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;
import fi.yle.broadcasting.LocationCloudUploader.Error;
import fi.yle.broadcasting.storage.StorageIOException;

public class LocationUploadViewController {
    
    private Context context;
    private LocationCloudUploader locationUploader;
    
    private Animation rotateAnimation;
    private View uploadView;
    private ImageView refreshIconView;
    private TextView countView;
    
    private boolean isRegistered;
    
    private BroadcastReceiver receiver = new BroadcastReceiver() {
        
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();

            if (action.equals(LocationCloudUploader.ACTION_LOCATION_UPLOADING_DID_START)) {
                startAnimation();
            } else if (action.equals(LocationCloudUploader.ACTION_LOCATION_UPLOADING_DID_FINISH)) {
                Error error = (Error) intent.getExtras().get(LocationCloudUploader.EXTRA_ERROR);
                if (!error.equals(Error.NO_ERROR)) {
                    showStorageUploadFailureDialog(error);
                }
                stopAnimation();
            } else {
                stopAnimation();
                updateLocationCount();
            }
        }
    };
    
    public LocationUploadViewController(Context context, LocationCloudUploader locationUploader, View uploadView) {
        this.context = context;
        this.locationUploader = locationUploader;
        this.rotateAnimation = AnimationUtils.loadAnimation(context, R.anim.clockwise_spinner_rotation);
        
        this.uploadView = uploadView;
        this.refreshIconView = (ImageView) uploadView.findViewById(R.id.refresh_icon);
        
        if (this.refreshIconView == null) {
            throw new IllegalStateException("Invalid uploadView, refresh icon not found");
        }
        
        this.countView = (TextView) uploadView.findViewById(R.id.actionbar_location_count_textview);
        
        if (countView == null) {
            throw new IllegalStateException("Invalid uploadView, location count is not found");
        }
        
        this.isRegistered = false;
    }
    
    public void register() {
        if (this.isRegistered) {
            throw new IllegalStateException("Already registered");
        }
        
        this.isRegistered = true;
        
        updateLocationCount();
        
        IntentFilter intentFilter = new IntentFilter();
        
        intentFilter.addAction(LocationCloudUploader.ACTION_LOCATION_UPLOADING_DID_START);
        intentFilter.addAction(LocationCloudUploader.ACTION_LOCATION_UPLOADING_DID_FINISH);
        intentFilter.addAction(LocationCloudUploader.ACTION_SAVED_LOCATION_COUNT_DID_CHANGE);
        
        this.context.registerReceiver(this.receiver, intentFilter);
        
        
        this.uploadView.setOnClickListener(new OnClickListener() {
            
            @Override
            public void onClick(View v) {
                LocationUploadViewController.this.locationUploader.uploadLocations();
            }
        });
        
        
        if (this.locationUploader.isUploadingLocations()) {
            startAnimation();
        } else {
            this.locationUploader.uploadLocations();
        }
    }
    
    public void unregister() {
        if (!this.isRegistered) {
            return;
        }
        
        this.context.unregisterReceiver(this.receiver);
        this.uploadView.setOnClickListener(null);
        stopAnimation();
        
        this.isRegistered = false;
    }
    
    private void startAnimation() {
        this.refreshIconView.startAnimation(this.rotateAnimation);
    }
    
    private void stopAnimation() {
        this.rotateAnimation.cancel();
    }
    
    private void updateLocationCount() {
        try {
            long savedLocationCount = this.locationUploader.getSavedLocationCount();
            if (savedLocationCount != 0) {
                showUploadView();
                this.countView.setText(Long.toString(savedLocationCount));
            } else {
                hideUploadView();
            }
        } catch (StorageIOException e) {
            e.printStackTrace();
            showLocationCountFailureDialog();
        }
    }
    
    private void showLocationCountFailureDialog() {
        AlertDialog.Builder dialog = new AlertDialog.Builder(context);
        dialog.setTitle(context.getString(R.string.error_dialog_title));
        dialog.setPositiveButton(R.string.error_dialog_ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }

        });
        dialog.setMessage(R.string.storage_location_count_failure);
        dialog.show();
        
    }
    
    private void showStorageUploadFailureDialog(Error error) {
        AlertDialog.Builder dialog = new AlertDialog.Builder(context);
        dialog.setTitle(context.getString(R.string.error_dialog_title));
        dialog.setPositiveButton(R.string.error_dialog_ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }

        });
        dialog.setMessage(getLocalizedStorageError(error));
        dialog.show();
        
    }
           
    private String getLocalizedStorageError(Error error) {
       
       int msg = R.string.storage_error_unexpected_error; 
       
       switch (error) {
       case CLOUD_FAILURE:
          msg = R.string.storage_error_cloud;
          break;
          
       case LOCATION_DELETE_FAILED:
          msg = R.string.storage_error_location_delete_failed;
          break;
          
       case LOCATION_GET_FAILED:
          msg = R.string.storage_error_location_get_failed;
          break;

       default:
          break;
       }
       
       return this.context.getString(msg);
    }
    
    private void showUploadView() {
        this.refreshIconView.setVisibility(View.VISIBLE);
        this.countView.setVisibility(View.VISIBLE);
    }
    
    private void hideUploadView() {
        this.refreshIconView.setVisibility(View.GONE);
        this.countView.setVisibility(View.GONE);
    }

}
