package fi.yle.broadcasting.storage;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import android.content.Context;

import com.j256.ormlite.dao.Dao;
import com.j256.ormlite.stmt.QueryBuilder;

import fi.yle.broadcasting.model.BroadcastType;
import fi.yle.broadcasting.model.DeviceType;
import fi.yle.broadcasting.model.Location;
import fi.yle.broadcasting.model.LocationDetails;
import fi.yle.broadcasting.model.NetworkType;
import fi.yle.broadcasting.model.SignalType;
import fi.yle.broadcasting.storage.db.YleDbOpenHelper;
import fi.yle.broadcasting.storage.db.model.LocationEntity;

public class Storage {
    
    private YleDbOpenHelper databaseHelper;

    public Storage(Context context) {
        this.databaseHelper = new YleDbOpenHelper(context);
    }

    /**
     * Saves location to the storage.
     *
     * Creates new location if storageId is not set,
     * updates otherwise.
     * 
     * @param location to save. Will have storageId set on successful save.
     * 
     * @return stored location with storageId set.
     * 
     * @throws StorageIOException on failure to save location.
     */
    public void saveLocation(Location location) throws StorageIOException {
        try {
            Dao<LocationEntity, String> locationDao = this.databaseHelper.getDao(LocationEntity.class);
            
            LocationEntity locationEntity = locationToEntity(location);
            locationDao.createOrUpdate(locationEntity);
            
            if (location.getStorageId() == null) {
                location.setStorageId(locationEntity.getId());
            }
        } catch (SQLException e) {
            throw new StorageIOException("Failed to save location", e);
        }
    }
    
    /**
     * Search locations by name.
     * 
     * If given name is empty will return all locations.
     * 
     * @param searchKey  key to compare locations name with.
     *  
     * @return list of locations which name contains searchKey. Ordered ascending by name.
     * 
     * @throws StorageIOException on search failure.
     */
    public List<Location> searchLocationsByName(String searchKey)
            throws StorageIOException {
        
        if (searchKey == null) {
            throw new IllegalStateException("searchKey can not be null");
        }
        
        try {
            Dao<LocationEntity, String> locationDao = this.databaseHelper.getDao(LocationEntity.class);
            QueryBuilder<LocationEntity, String> queryBuilder = locationDao.queryBuilder();
            
            queryBuilder.where().like("name", searchKey);
            queryBuilder.orderBy("name", true);
            
            List<LocationEntity> entities = locationDao.query(queryBuilder.prepare());
            List<Location> locations = new ArrayList<Location>(entities.size());

            for (LocationEntity e : entities) {
                locations.add(entityToLocation(e));
            }

            return locations;
        } catch (SQLException e) {
            throw new StorageIOException("Location search with searchKey: '" + searchKey + "' failed", e);
        }
    }
    
    /**
     * Get all stored locations.
     * 
     * @return list of stored locations. Ordered ascending by name.
     *  
     * @throws StorageIOException on failure to get locations.
     */
    public List<Location> getAllLocations() throws StorageIOException {
        try {
            Dao<LocationEntity, String> locationDao = this.databaseHelper.getDao(LocationEntity.class);
            QueryBuilder<LocationEntity, String> queryBuilder = locationDao.queryBuilder();
            
            queryBuilder.orderBy("name", true);
            
            List<LocationEntity> entities = locationDao.query(queryBuilder.prepare());
            List<Location> locations = new ArrayList<Location>(entities.size());
            
            for (LocationEntity e : entities) {
                locations.add(entityToLocation(e));
            }

            return locations;
            
        } catch (SQLException e) {
            throw new StorageIOException("Failed to get locations", e);
        }
    }
    
    /**
     * Get stored location count.
     * 
     * @return location count.
     * 
     * @throws StorageIOException on failure to get count.
     */
    public long getLocationCount() throws StorageIOException {
        try {
            return this.databaseHelper.getDao(LocationEntity.class).countOf();
        } catch (SQLException e) {
            throw new StorageIOException("Failed to get locations' count", e);
        }
    }
    
    /**
     * Delete location by location storageId.
     * 
     * @param locationStorageId    location storageId to delete location with.
     * 
     * @throws StorageIOException on failure to delete location.
     */
    public void deleteLocation(int locationStorageId) throws StorageIOException {
        try {
            Dao<LocationEntity, Integer> locationDao = this.databaseHelper.getDao(LocationEntity.class);
            locationDao.deleteById(locationStorageId);
        } catch (SQLException e) {
            throw new StorageIOException("Failed to delete location", e);
        }
    }

    private LocationEntity getLocationEntity(int locationStorageId) throws StorageIOException {
        try {
            Dao<LocationEntity, String> locationDao = this.databaseHelper.getDao(LocationEntity.class);
            return locationDao.queryForId(String.valueOf(locationStorageId));
        } catch (SQLException e) {
            throw new StorageIOException("Failed to get location by id: " + locationStorageId, e);
        }
    }
    
    private Location entityToLocation(LocationEntity locationEntity) throws StorageIOException {        
        LocationDetails locationDetails = new LocationDetails(
                locationEntity.getLongitude(),
                locationEntity.getLatitude(),
                DeviceType.valueOf(locationEntity.getDevice()),
                NetworkType.valueOf(locationEntity.getNetwork()),
                BroadcastType.valueOf(locationEntity.getBroadcast()),
                SignalType.valueOf(locationEntity.getMeasurement()),
                locationEntity.getDetails(),
                locationEntity.getElectricitySources(),
                locationEntity.getImagePath());

        Location location = new Location(
                locationEntity.getId(),
                locationEntity.getCloudId(),
                locationEntity.getName(),
                locationDetails);
        
        return location;
    }

    private LocationEntity locationToEntity(Location location) throws StorageIOException {
        LocationEntity locationEntity = null;
        Integer locationStorageId = location.getStorageId(); 
        
        if (locationStorageId != null) {
            locationEntity = getLocationEntity(locationStorageId);
            
            if (locationEntity == null) {
                throw new StorageIOException("Can not find location with storageId: " + locationStorageId);
            }
        } else {
            locationEntity = new LocationEntity();
        }
        
        locationEntity.setCloudId(location.getCloudId());
        locationEntity.setName(location.getName());
        locationEntity.setLongitude(location.getDetails().getLongitude());
        locationEntity.setLatitude(location.getDetails().getLatitude());
        locationEntity.setDevice(location.getDetails().getDeviceType().getValue());
        locationEntity.setNetwork(location.getDetails().getNetworkType().getValue());
        locationEntity.setBroadcast(location.getDetails().getBroadcastType().getValue());
        locationEntity.setMeasurement(location.getDetails().getSignalType().getValue());
        locationEntity.setDetails(location.getDetails().getDetails());
        locationEntity.setElectricitySources(location.getDetails().getElectricitySources());
        locationEntity.setImagePath(location.getDetails().getImageUri());

        return locationEntity;
    }

}
