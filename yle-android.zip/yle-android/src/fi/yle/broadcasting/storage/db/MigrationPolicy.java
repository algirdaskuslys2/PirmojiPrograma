package fi.yle.broadcasting.storage.db;

import java.sql.SQLException;

import android.database.sqlite.SQLiteDatabase;

import com.j256.ormlite.support.ConnectionSource;

public interface MigrationPolicy {
    
    public void migrate(
            SQLiteDatabase db,
            ConnectionSource connectionSource) throws SQLException;
    
    /**
     * Get version, migration policy migrates from.
     * Will always migrate to version: getVersion() + 1
     */
    public int getVersion();

}
