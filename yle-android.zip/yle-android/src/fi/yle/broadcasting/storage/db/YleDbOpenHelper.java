package fi.yle.broadcasting.storage.db;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import fi.yle.broadcasting.storage.db.model.LocationEntity;

public class YleDbOpenHelper extends DatabaseOpenHelper {
    
    public YleDbOpenHelper(Context context) {
        super(context, dbDescriptor());
    }

    private static DatabaseDescriptor dbDescriptor() {
        List<Class<?>> entityClasses = new ArrayList<Class<?>>();
        entityClasses.add(LocationEntity.class);
        
        MigrationAssistant migrationAssistant = new MigrationAssistant();
        
        return new DatabaseDescriptor(
                "yle.db",
                1,
                entityClasses,
                migrationAssistant);
    }
    
}
