package fi.yle.broadcasting.storage.db.model;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable
public class LocationEntity {
    @DatabaseField(canBeNull = false, generatedId = true)
    private Integer id;
    
    @DatabaseField(canBeNull = true, unique = true)
    private String cloudId;
    
    @DatabaseField(canBeNull = false)
    private String name;
    
    @DatabaseField(canBeNull = false)
    private Double longitude;
    
    @DatabaseField(canBeNull = false)
    private Double latitude;
    
    @DatabaseField(canBeNull = false)
    private Integer device;
    
    @DatabaseField(canBeNull = false)
    private Integer network;
    
    @DatabaseField(canBeNull = false)
    private Integer broadcast;
    
    @DatabaseField(canBeNull = false)
    private Integer measurement;
    
    @DatabaseField(canBeNull = true)
    private String details;
    
    @DatabaseField(canBeNull = true)
    private String electricitySources;
    
    @DatabaseField(canBeNull = true)
    private String imagePath;
    
    public LocationEntity() {
        // required by ORMLite
    }
    
    public LocationEntity(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return this.id;
    }

    public String getCloudId() {
        return this.cloudId;
    }
    
    public void setCloudId(String cloudId) {
        this.cloudId = cloudId;
    }
    
    public String getName() {
        return this.name;
    }
    
    public void setName(String name) {
        this.name = name;
    }

    public Double getLongitude() {
        return this.longitude;
    }
    
    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public Double getLatitude() {
        return this.latitude;
    }
    
    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public Integer getDevice() {
        return this.device;
    }
    
    public void setDevice(int device) {
        this.device = device;
    }

    public Integer getNetwork() {
        return this.network;
    }
    
    public void setNetwork(int network) {
        this.network = network;
    }

    public Integer getBroadcast() {
        return this.broadcast;
    }
    
    public void setBroadcast(int broadcast) {
        this.broadcast = broadcast;
    }

    public Integer getMeasurement() {
        return this.measurement;
    }
    
    public void setMeasurement(int measurement) {
        this.measurement = measurement;
    }

    public String getDetails() {
        return this.details;
    }
    
    public void setDetails(String details) {
        this.details = details;
    }

    public String getElectricitySources() {
        return this.electricitySources;
    }
    
    public void setElectricitySources(String electricitySources) {
        this.electricitySources = electricitySources;
    }

    public String getImagePath() {
        return this.imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }
    
}
