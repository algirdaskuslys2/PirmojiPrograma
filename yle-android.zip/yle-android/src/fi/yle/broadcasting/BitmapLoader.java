package fi.yle.broadcasting;

import java.io.IOException;
import java.util.Locale;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;

public class BitmapLoader {
  
    private static final int DEFAULT_BITMAP_WIDTH = 512;
    private static final int DEFAULT_BITMAP_HEIGHT = 512;
    
    private String imageUri;
    
    private int requiredWidth;
    private int requiredHeight;
    
    
    private FileLoadingThread fileLoadingThread;
    
    private Handler mainHandler;
    
    private volatile boolean isCanceled;
    
    public interface OnBitmapLoadedCallback {
        public void onSuccess(Bitmap bitmap);
        public void onFailure(IOException error);
    }
    
    private class FileLoadingThread extends Thread {
        
        private OnBitmapLoadedCallback callback;
        
        public FileLoadingThread(OnBitmapLoadedCallback callback) {
            super("LocationBitmapLoader.LoadingThread");
            
            this.callback = callback;
        }
        
        @Override
        public void run() {
            if (BitmapLoader.this.isCanceled) {
                return;
            }
            
            Bitmap bitmap = loadBitmap();
            if (bitmap != null) {
                notifySuccess(loadBitmap());
            } else {
                notifyError(new IOException("Failed to create bitmap from path: " + BitmapLoader.this.imageUri));
            }
        }
        
        private Bitmap loadBitmap() { 
            BitmapFactory.Options boundsOptions = new BitmapFactory.Options();
            boundsOptions.inJustDecodeBounds = true;
            
            BitmapFactory.decodeFile(BitmapLoader.this.imageUri, boundsOptions);
            
            int imageWidth = boundsOptions.outWidth;
            int imageHeight = boundsOptions.outHeight;
            
            if (imageWidth == -1 || imageHeight == -1) {
                return null;
            }
            
            BitmapFactory.Options bitmapOptions = new BitmapFactory.Options();
            bitmapOptions.inSampleSize = calculateInSampleSize(imageWidth, imageHeight);    
            
            return BitmapFactory.decodeFile(BitmapLoader.this.imageUri, bitmapOptions); 
        }
        
        private int calculateInSampleSize(int imageWidth, int imageHeight) {
            int reqWidth = BitmapLoader.this.requiredWidth;
            int reqHeight = BitmapLoader.this.requiredHeight;
            
            int inSampleSize = 1;
            
            if (imageHeight > reqHeight || imageWidth > reqWidth) {
                final int halfHeight = imageHeight / 2;
                final int halfWidth = imageWidth / 2;
                
                // Calculate the largest inSampleSize value that is a power of 2 and keeps both
                // height and width larger than the requested height and width.
                while ((halfHeight / inSampleSize) > reqHeight
                        && (halfWidth / inSampleSize) > reqWidth) {
                    inSampleSize *= 2;
                }
            }
            
            return inSampleSize;
        }
        
        private void notifySuccess(final Bitmap bitmap) {
            BitmapLoader.this.mainHandler.post(new Runnable() {
                
                @Override
                public void run() {
                    if (BitmapLoader.this.isCanceled) {
                        bitmap.recycle();
                        return;
                    }
                    
                    FileLoadingThread.this.callback.onSuccess(bitmap);
                }
            });
        }
        
        private void notifyError(final IOException error) {
            BitmapLoader.this.mainHandler.post(new Runnable() {
                
                @Override
                public void run() {
                    if (BitmapLoader.this.isCanceled) {
                        return;
                    }
                    
                    FileLoadingThread.this.callback.onFailure(error);
                }
            });
        }
        
    }
    
    public BitmapLoader(String imageUri, int requiredWidth, int requiredHeight) {
        this.imageUri = imageUri;
        
        this.requiredWidth = requiredWidth;
        this.requiredHeight = requiredHeight;
        
        if (this.requiredWidth == 0) {
            this.requiredWidth = DEFAULT_BITMAP_WIDTH;
        }
        
        if (this.requiredHeight == 0) {
            this.requiredHeight = DEFAULT_BITMAP_HEIGHT;
        }
        
        this.fileLoadingThread = null;
        
        this.mainHandler = new Handler();
        
        this.isCanceled = false;
    }
    
    public void loadBitmap(final OnBitmapLoadedCallback callback) {
        if (isLoading() || isCanceled()) {
            throw new IllegalStateException("Already loading or canceled");
        }
        
        OnBitmapLoadedCallback callbackProxy = new OnBitmapLoadedCallback() {
            
            @Override
            public void onSuccess(Bitmap bitmap) {
                BitmapLoader.this.fileLoadingThread = null;
                callback.onSuccess(bitmap);
            }
            
            @Override
            public void onFailure(IOException error) {
                BitmapLoader.this.fileLoadingThread = null;
                callback.onFailure(error);
            }
        };
        
            loadFileBitmap(callbackProxy);
    }
    
    public void cancel() {
        this.isCanceled = true;
    }
    
    public boolean isLoading() {
        return !isCanceled()
                && (this.fileLoadingThread != null);
    }
    
    public boolean isCanceled() {
        return this.isCanceled;
    }
    
    private boolean isCloudImage() {
        return this.imageUri.toLowerCase(Locale.US).startsWith("http");
    }

    private void loadFileBitmap(OnBitmapLoadedCallback callback) {
        this.fileLoadingThread = new FileLoadingThread(callback);
        this.fileLoadingThread.start();
    }
  
}
