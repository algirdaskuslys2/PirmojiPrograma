package fi.yle.broadcasting.storage.db;

import android.test.AndroidTestCase;

public class DatabaseTestCase extends AndroidTestCase{
private static final String DESTINATION_DB = "yle.db";
    
    @Override
    protected void setUp() throws Exception {
        super.setUp();
        
        String testMethodName = getName();
        
        if (testMethodName.equals("testAndroidTestCaseSetupProperly")) {
            return;
        }

        deleteDb();
    }
    
    @Override
    protected void tearDown() throws Exception {
        super.tearDown();
        
        if (getName().equals("testAndroidTestCaseSetupProperly")) {
            return;
        }
        
        deleteDb();
    }
        
    private void deleteDb() {
        getContext().deleteDatabase(DatabaseTestCase.DESTINATION_DB);
    }
    
}
