package fi.yle.broadcasting.storage;

import java.util.ArrayList;
import java.util.List;

import fi.yle.broadcasting.model.BroadcastType;
import fi.yle.broadcasting.model.DeviceType;
import fi.yle.broadcasting.model.Location;
import fi.yle.broadcasting.model.LocationDetails;
import fi.yle.broadcasting.model.NetworkType;
import fi.yle.broadcasting.model.SignalType;
import fi.yle.broadcasting.storage.db.DatabaseTestCase;

public class StorageTest extends DatabaseTestCase {
    
    private Storage storage;
    
    private Location locationA;
    private Location locationB;
    
    private LocationDetails locationDetailsA;
    private LocationDetails locationDetailsB;
    
    @Override
    protected void setUp() throws Exception {
        super.setUp();
        
        this.storage = new Storage(getContext());
        
        List<Location> locationsList = new ArrayList<Location>();
        
        this.locationDetailsA = new LocationDetails(
                54.9, 
                23.9, 
                DeviceType.YleDeviceMobilePhone, 
                NetworkType.YleNetworkInternet, 
                BroadcastType.YleBroadcastAudioRecorded, 
                SignalType.YleMeasurementSignalGood, 
                "Some details about Kaunas city", 
                "High voltage", 
                null);
        
        this.locationDetailsB = new LocationDetails(
                54.6833333, 
                25.3166667, 
                DeviceType.YleDeviceNormalVehicle, 
                NetworkType.YleNetworkMobileGate, 
                BroadcastType.YleBroadcastVideoRecorded, 
                SignalType.YleMeasurementSignalNone, 
                "Some details about Vilnius city", 
                "No voltage", 
                "myUrl/path/path1/image.jpg");
    
        this.locationA = new Location(
                null,
                "666",
                "Kaunas",
                this.locationDetailsA
                );
        
        this.locationB = new Location(
                null,
                "999",
                "Vilnius",
                this.locationDetailsB
                );
        
        this.storage.saveLocation(this.locationA);
        this.storage.saveLocation(this.locationB);
        
        assertNotNull(this.locationA.getStorageId());
        assertNotNull(this.locationB.getStorageId());
        
        locationsList = this.storage.getAllLocations();
        assertEquals(2, locationsList.size());

        assertLocationsEqual(this.locationA, locationsList.get(0));
        assertLocationsEqual(this.locationB, locationsList.get(1));
        
    }
    
    public void testSearchingSingleLocationByName() throws StorageIOException {
    	List<Location> locationList = new ArrayList<Location>();
    	locationList = this.storage.searchLocationsByName(this.locationB.getName());
        
    	assertLocationsEqual(this.locationB, locationList.get(0));
    }
    
    public void testDeletingSingleLocationById() throws StorageIOException {
        this.storage.deleteLocation(this.locationA.getStorageId());
        
        List<Location> locationList = new ArrayList<Location>();
        locationList = this.storage.getAllLocations();
        
        assertEquals(1, locationList.size());
        assertLocationsEqual(this.locationB, locationList.get(0));
    }
    
    private static void assertLocationsEqual(Location a, Location b) {
        assertEquals(a.getName(),                                b.getName());
        assertEquals(a.getDetails().getLongitude(),              b.getDetails().getLongitude());
        assertEquals(a.getDetails().getLatitude(),               b.getDetails().getLatitude());
        assertEquals(a.getDetails().getDeviceType(),             b.getDetails().getDeviceType());
        assertEquals(a.getDetails().getNetworkType(),            b.getDetails().getNetworkType());
        assertEquals(a.getDetails().getBroadcastType(),          b.getDetails().getBroadcastType());
        assertEquals(a.getDetails().getSignalType(),             b.getDetails().getSignalType());
        assertEquals(a.getDetails().getDetails(),                b.getDetails().getDetails());
        assertEquals(a.getDetails().getElectricitySources(),     b.getDetails().getElectricitySources());
        assertEquals(a.getDetails().getImageUri(), 				 b.getDetails().getImageUri());
        
    }

}
