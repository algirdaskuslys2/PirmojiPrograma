package fi.yle.broadcasting.cloud;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;
import android.test.InstrumentationTestCase;
import android.util.Log;
import fi.yle.broadcasting.image.ImageFile;
import fi.yle.broadcasting.image.ImageFile.Format;
import fi.yle.broadcasting.model.BroadcastType;
import fi.yle.broadcasting.model.DeviceType;
import fi.yle.broadcasting.model.Location;
import fi.yle.broadcasting.model.LocationDetails;
import fi.yle.broadcasting.model.NetworkType;
import fi.yle.broadcasting.model.SignalType;

public class LocationRequestDataTest extends InstrumentationTestCase {

	private Location location;
	private InputStream inputStream;
	
	@Override
	protected void setUp() throws Exception {
		super.setUp();
		
		Context context = getInstrumentation().getContext();
		File file = ImageFile.createFromInputStream(
				context, 
				context.getAssets().open("images/img.jpg"),
				Format.JPG, null);
		
		this.location = new Location(
				123, "cloudId",
				"locationName",
				new LocationDetails(
						10.10, 20.20,
						DeviceType.YleDeviceHeavyDutyVehicle,
						NetworkType.YleNetworkEth,
						BroadcastType.YleBroadcastAudioLive, 
						SignalType.YleMeasurementSignalAverage,
						"locationDetails",
						"electicitySources",
						file.getPath()));
		
		LocationRequestData requestData = new LocationRequestData(location);
		this.inputStream = requestData.open();
	}
	
	@Override
	protected void tearDown() throws Exception {
		super.tearDown();
		
		File imageFile = new File(this.location.getDetails().getImageUri());
		imageFile.delete();
		
		try {
			this.inputStream.close();
		} catch (IOException e) {
		}
	}
	
	public void testGettingStreamData() throws Exception {
		String str = readString(this.inputStream);
		
		Log.d("json-start", str.substring(0, 500));
		Log.d("json-end", str.substring(str.length() - 500));
		
		JSONObject json = new JSONObject(str);
		assertLocationJson(this.location, json);
	}
	
	private void assertLocationJson(Location location, JSONObject json) throws JSONException, IOException {
		assertFalse(json.has("storageId"));
		assertEquals(location.getCloudId(), json.getString("id"));
		assertEquals(location.getName(), json.getString("name"));
		assertEquals(location.getDetails().getLongitude(), json.getDouble("longitude"));
		assertEquals(location.getDetails().getLatitude(), json.getDouble("latitude"));
		assertEquals(location.getDetails().getDeviceType().getValue(), json.getInt("device"));
		assertEquals(location.getDetails().getNetworkType().getValue(), json.getInt("network"));
		assertEquals(location.getDetails().getBroadcastType().getValue(), json.getInt("broadcast"));
		assertEquals(location.getDetails().getSignalType().getValue(), json.getInt("measurement"));
		assertEquals(location.getDetails().getDetails(), json.getString("details"));
		assertEquals(location.getDetails().getElectricitySources(), json.getString("electricitySources"));
		
		File imageFile = new File(location.getDetails().getImageUri());
		
		String expectedImage = encodeBase64(imageFile);
		String actualImage = json.getString("image");
		
		assertEquals(expectedImage, actualImage);
	}
	
	private static byte[] readBytes(InputStream inputStream) throws IOException {
		ByteArrayOutputStream baos = null;
		BufferedInputStream bis = null;
		
		try {
			baos = new ByteArrayOutputStream();
			bis = new BufferedInputStream(inputStream);
			
			byte[] buffer = new byte[1024];
			int bytesRead = -1;
			
			while ((bytesRead = bis.read(buffer)) != -1) {
				baos.write(buffer, 0, bytesRead);
			}
			
			return baos.toByteArray();
        } finally {
            try {
                bis.close();
            } catch (IOException e) {
            }
            
            try {
            	baos.close();
            } catch (IOException e) {
            }
        }
	}
	
	private static String readString(InputStream inputStream) throws IOException {
		return new String(readBytes(inputStream), "UTF-8");
	}
	
	private static String encodeBase64(File file) throws IOException {
	FileInputStream fis = new FileInputStream(file);
	Base64EncodingInputStream b64EncodeIn = new Base64EncodingInputStream(fis);

	return readString(b64EncodeIn);
}
	
}
